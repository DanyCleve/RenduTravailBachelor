#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
" Fonctionnement : Cette fonction a pour but de créer une table de donnée 
"                  portant le nom de fire_data dans la base de donnée DynamoDB
"                  qui contiendra les données de nos capteurs. Ces données sont 
"                  reçues dans la variable "event" et passer en parametre 
"                  dans notre gestionnaire de fonction (function_handler)
"                  
"                  
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

import logging
import couchdb


# Connnexion à la base de donnée
couch = couchdb.Server('http://admin:admin@raspberrypi.local:5985')


# nous verifions si notre base de donnée existe dans le cas contraire nous la créons
dbname = "fire_data"
if dbname in couch:
    print('Database already exist')
    # Selection de notre base de donnée
    db = couch[dbname]
else:
    # Création de notre base de donnée
    db = couch.create('sensor_data')
    print('Database created')


# Initialisation du logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

"""
@summary:		 Cette méthode permet d'écrire des données dans la table 
                 fire_data
				 
@param points: 	  event: données d'évenement dans lequel on retrouve les données 
                  à écrire dans la table
                  context: informations d'execution de notre fonction

@returns : 		  -------
"""
def function_handler(event, context):

    # récupération de l'evennement et extraction des valeurs
    logger.info(event)
    
    uuid      = event["uuid"]
    time      = event["time"]
    value     = event["value"]
    valueType = event["type"]
    location  = event["location"]
    
    logger.info("uuid : " + uuid)
    logger.info("time : " + str(time))
    logger.info("value : " + str(value))
    logger.info("type : " + valueType)
    logger.info("location : " + location)

    # objet JSON qui sera sauvegarder dans la base de donnée couchdb
    Data={
        'uuid':uuid,
        'time':time,
        'value':value,
        'type':valueType,
        'location':location
    }
    # sauvegarde des données dans la base de données
    db.save(Data)

    return
