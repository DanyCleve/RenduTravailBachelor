function(doc) {
  emit(doc.property_to_index);
}
